# [Doodle Cricket](https://play.google.com/store/apps/details?id=com.asissuthar.cricket)

Welcome to the Doodle Cricket Game! Powered By Advance AI Algorithms. This is a game built for you the cricket fan! Every cricket lover can now have the most lightweight mobile cricket game at the palm of their hands! You can play the maximum number of cricket shots without having over limits. Be prepared for awesome fun!

## [Play Now](https://doodlecricket.github.io)

## [Download](https://play.google.com/store/apps/details?id=com.asissuthar.cricket)

Features:

- Tap to Play
- Most lightweight Game with awesome Graphics
- Dynamic camera angles
- Challenging AI opponent
- Realistic Physics
- Dynamic Ambiance
- Share Score on Social Networks

### [Twitter @doodlecricket](https://twitter.com/doodlecricket)
